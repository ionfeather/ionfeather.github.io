---
title: Molecule Repurposing-2
slug: MoleculeRepurposing-2
description: 
date: 2025-04-04T01:42:58+08:00
lastmod: 2025-04-04T01:42:58+08:00
image: 
math: true
license: 
hidden: false
draft: false
categories:
  - ""
tags:
---

## 阅读综述

- Ai-Driven Drug Repurposing: Uncovering Hidden Potentials OfEstablished Medications For Rare Disease Treatment
- Structure-based drug repurposing: Traditional and advanced AI/ML-aided methods
- Artificial intelligence for drug repurposing against infectious diseases | _Artificial Intelligence Chemistry 2024_
- Artificial intelligence in COVID-19 drug repurposing | *The Lancet Digital Health*

## 可用的模型

目前的再利用方法的实例主要集中在**网络医学和大规模的患者数据分析**上。这里有**CoV-KGE、BenevolentAI、异质有向生物医学图**等。

## 例子

### Artificial intelligence in drug development | *nature medicine*

这是一篇综述，讲解了人工智能在药物发现中的应用取得了显著进展，特别是在靶点识别、虚拟筛选、新药设计（de novo design）、ADMET预测和合成规划等方面。

这里主要关注他讲的AI在药物重定位中的作用。

### A foundation model for clinician-centered drug repurposing | *nature medicine*

#### 摘要

文章介绍了药物再利用人工智能模型在临床应用中的局限性，并提出了本研究的核心——TxGNN模型。

#### 解决的问题

目前的模型过于依赖**已有疗法**和**关于此疾病详细的分子机制**，对于多疾病、零样本情境下的药物再利用没有好用的模型。

#### 挑战是什么

- **现有计算方法假设待预测疾病已有可用药物**，然而大量疾病（研究中 92% 的 17,080 种疾病）缺乏已知适应症，罕见病中约 95% 无 FDA 批准药物，85% 甚至无有潜力的治疗药物，
- **药物重利用的适应症可能与最初研究的适应症无关**，现有机器学习模型对数据不完整、稀疏且无已知疗法的疾病，识别治疗候选药物的能力大幅下降。

#### 核心方法

TxGNN。图基础模型，在医学知识图谱上训练，利用图神经网络和度量学习模块，将药物再利用问题转化为零样本预测问题。  
![](assets/20250330192550.png)

TxGNN模型主要由两个模块组成：TxGNN Predictor（预测模块）和TxGNN Explainer（解释模块）。

1. **TxGNN Predictor（预测模块）**：
	- **功能**：预测药物的适应症（indications）和禁忌症（contraindications）。
	- **架构**：该模块基于图神经网络（GNN）构建，优化了医学知识图谱（KG）中的关系。通过大规模、自监督的**预训练**，GNN为KG中的所有概念生成有意义的表示。然后，通过**微调**，该预训练模型被适应于处理治疗任务，并预测跨多种疾病的药物候选适应症和禁忌症。
	- **度量学习模块**：用于零样本预测，利用疾病可以共享疾病相关的遗传和基因组网络这一见解，**从可治疗的疾病向无治疗方法的疾病转移知识**。
2. **TxGNN Explainer（解释模块）**：
	- **功能**：解析KG，提取并简洁地表示相关医学知识，以生成**多跳可解释的路径**，这些路径解释了模型预测背后的逻辑。
	- **架构**：使用名为**GraphMask**的自我解释性方法，生成一个稀疏但充分的医学概念子图，这些概念被认为是TxGNN预测的关键。它为KG中的每条边生成一个0到1之间的重要性分数，并通过组合药物-疾病子图和边重要性分数，产生多跳可解释的路径，将疾病与预测药物联系起来。
#### 优势

在零样本条件下，TxGNN预测效果相比别的模型体现出了广泛的泛化性和准确性。

#### 数据集

医学知识图谱公开，包含 10 种类型的节点和 29 种类型的无向边，共有 123,527 个节点和 8,063,026 条边，涵盖 17,080 种疾病（92% 缺乏 FDA 批准药物）和 7,957 种潜在药物重利用候选药物，还包含生物过程、分子功能、蛋白质、表型等多种生物医学概念信息。

- 知识图谱下载地址：[PrimeKG](https://doi.org/10.7910/DVN/IXA7BM)
- 演示界面：[TxGNN Explorer](http://txgnn.org/)
- Github仓库：[mims-harvard/TxGNN](https://github.com/mims-harvard/TxGNN)

---
### In Silico Drug Repurposing for Anti-Inflammatory Therapy: Virtual Search for Dual Inhibitors of Caspase-1 and TNF-Alpha

[In Silico Drug Repurposing for Anti-Inflammatory Therapy: Virtual Search for Dual Inhibitors of Caspase-1 and TNF-Alpha - PubMed](https://pubmed.ncbi.nlm.nih.gov/34944476/)

#### 摘要

炎症与多种疾病相关，caspase-1 和 TNF-alpha 在炎症发展中起关键作用，针对二者的双重抑制剂有望治疗多种炎症性疾病。本文构建了基于定量构效关系和多层感知器神经网络的多条件模型（mtc-QSAR-MLP）用于虚拟筛选抗炎药物。经数据集处理、模型开发与评估，该模型准确性超 88%。利用此模型筛选出如 linagliptin、icariin 和 rolipram 等潜在的 caspase-1 和 TNF-alpha 双重抑制剂，为抗炎治疗提供新方向，有望用于自身免疫疾病、癌症及 COVID-19 等疾病的治疗。

#### 解决的问题

**caspase-1 和 TNF-alpha**是炎症发展中的关键蛋白，针对它们的双重抑制剂有望治疗多种炎症性疾病。

#### 挑战是什么

通过药物再利用的方式来加速抗炎药物的发现。

#### 核心方法

构建基于定量结构 - 活性关系（QSAR）和多层感知器神经网络（MLP）的多条件模型（mtc-QSAR-MLP），用于虚拟筛选 caspase-1 和 TNF-alpha 的双重抑制剂。

1. **数据处理与分子描述符计算**：从 [ChEMBL](https://chembl.gitbook.io/chembl-interface-documentation/downloads)数据库获取 caspase-1 和 TNF-alpha 的化学及抑制数据，经筛选得到 1476 个分子案例。用[`MODESLAB v1.5`](https://insilicomoleculardesign.com/modeslab/)软件计算多种分子描述符，包括拓扑指数等。还通过 Box-Jenkins 方法融合化学和生物信息，得到能反映分子结构与实验条件关系的\(D[GTI]cj\)描述符，为模型构建提供丰富数据支持。
2. **mtc-QSAR-MLP 模型构建**
    - **数据集划分**：将数据集按 3:1 随机分为训练集（1111 个分子案例，占 75.27%）和测试集（365 个分子案例，占 24.73%） 。
    - **描述符筛选**：在训练集中，用信息增益比（IGR）对\(D[GTI]cj\)描述符排序，通过两两 Pearson 相关系数（PCC）筛选出相关性在\(-0.6 < PCC < 0.6\)的描述符，减少信息冗余。
    - **模型训练与选择**：以 MLP 神经网络为基础构建模型，利用 `STATISTICA v13.5.0.17` 软件分析不同 MLP 网络，依据敏感性（Sn (%)）、特异性（Sp (%)）、准确性（Acc (%)）和马修斯相关系数（MCC）等指标，选择性能最佳的 MLP 网络作为 mtc-QSAR-MLP 模型。
3. **模型评估**：采用 Bounding Box 方法确定模型适用性域，计算描述符的局部适用性域分数（\(LSAD_D [GTI] cj\)）和总分数（TSAD），判断分子是否在适用性域内。通过分析模型在训练集和测试集上的性能指标，如准确率、敏感性、特异性和 MCC 等，验证模型对不同实验条件下化学物质抑制活性的分类和预测能力。
4. **虚拟筛选与结果验证**：使用构建好的 mtc-QSAR-MLP 模型对 8922 种机构监管化学品数据库进行虚拟筛选，考虑 8 种实验条件，计算每个分子的 FA (%)（分子在 8 种实验条件下被预测为活性的频率）和 S (TSAD)（考虑 8 种实验条件下分子的总适用性域分数）指标，筛选潜在双重抑制剂。对筛选结果，通过在科学文献中搜索相关信息，结合实验证据验证其抑制 caspase-1 和 TNF-alpha 的可能性。

#### 优势

- **整合多源数据**：基于扰动理论和机器学习构建模型，能够整合不同类型的化学和生物数据。通过 Box-Jenkins 方法对传统分子描述符进行处理，得到融合化学结构与实验条件信息的描述符，使模型能综合考虑多种因素。
- **多靶点多终点预测**：可同时预测多个生物终点（如活性、毒性、药代动力学性质），并针对多个不同靶点（如 caspase-1 和 TNF-alpha）进行预测。
- **高预测准确性**：模型在训练集和测试集上都表现出较高的准确性。训练集准确率达 92.44%，测试集准确率为 88.49%，马修斯相关系数（MCC）在训练集和测试集分别为 0.844 和 0.764。
- **提供理化和结构解释**：通过对分子描述符的分析，能够从物理化学和结构层面解释模型的预测结果。

#### 数据集

[ChEMBL](https://chembl.gitbook.io/chembl-interface-documentation/downloads)开放数据库。

### Machine learning–enabled virtual screening indicates the anti-tuberculosis activity of aldoxorubicin and quarfloxin with verification by molecular docking, molecular dynamics simulations, and biological evaluations | *Briefings Bioinf*

#### 核心方法

研究者首先从ChEMBL数据库中收集了大量已知的抗结核药物的生物活性数据，用于训练和验证多种机器学习和深度学习模型。这些模型包括XGBoost和图神经网络（GNNs），用于预测化合物的最小抑制浓度（MIC）。接着，研究者使用这些模型对DrugBank数据库中的11,576种化合物进行虚拟筛选，筛选出具有潜在抗结核活性的化合物。通过多步过滤和实验验证，最终确定了两种具有显著抗结核活性的化合物：aldoxorubicin和quarfloxi，为了进一步验证作用机制，研究者通过分子对接、分子动力学模拟和表面等离子共振实验，确认了它们与结核分枝杆菌DNA gyrase的直接结合。

